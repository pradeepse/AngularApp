import { Component, OnInit } from '@angular/core';
import {Hero} from '../heroes/hero';
//import {Heroes} from '../heroes/mock-heroes';
import {HeroService} from 'app/hero.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {
  hero: Hero = { 
    id:2,
    name:'Pradeep'
    };
    strhero: string = 'Welcome';
    heroes: Hero[];

  constructor(private heroService:HeroService) { }

  getHeroes(): void {
    this.heroes = this.heroService.getHeroes();
  }

  ngOnInit() {
    this.getHeroes();
  }

}
