import { Component } from '@angular/core';

@Component({
    selector:'my-app',
    template:'Products',
})
export class Appproduct {
    
}