import { Component } from '@angular/core';
import {Http} from '@angular/http';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  //template: `
   //`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';

  constructor(private http:Http){}
  ngOnInit(){
    this.http.get("http://jsonplaceholder.typicode.com/users").
    subscribe((data) => console.log(data))
    }
    
  }

