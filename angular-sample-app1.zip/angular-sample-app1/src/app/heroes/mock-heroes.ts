import {Hero} from '../heroes/hero';

export const Heroes:Hero[] = [
    {id:11, name:'Apple'},
    {id:12, name:'Banana'},
    {id:13, name:'Chikku'}
];