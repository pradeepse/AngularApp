import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
//import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';

//added newly
import { Appproduct } from './product.component';
import { Appinventory } from './Inventory.component';
import { RouterModule, Routes } from '@angular/router';
import { HeroesComponent } from './heroes/heroes.component';
import {HeroService} from 'app/hero.service';
//added for HTTP service
import {HttpModule} from '@angular/http';
//added for angular version
import {VERSION} from '@angular/core';

const appRoutes: Routes = [
  {path: 'Product', component: Appproduct},
  {path:'Inventory', component:Appinventory}
];

@NgModule({
  declarations: [
    AppComponent,Appproduct,Appinventory, HeroesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule, //HTTP service
    RouterModule.forRoot(appRoutes),
    //HttpClientModule,
  ],
  providers: [HeroService],
  bootstrap: [AppComponent]
})
export class AppModule { }
