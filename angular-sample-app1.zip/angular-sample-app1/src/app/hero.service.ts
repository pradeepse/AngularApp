import { Injectable } from '@angular/core';
import {Hero} from '../app/heroes/hero';
import {Heroes} from '../app/heroes/mock-heroes';

@Injectable(
  //{
    //providedIn:'root',
  //}
  )

export class HeroService {

  getHeroes(): Hero[] {
    return Heroes;
  }
  constructor() { }

}
